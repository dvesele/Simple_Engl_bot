package com.simpleenglish.Simple_Engl_bot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleEnglBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleEnglBotApplication.class, args);
	}

}
