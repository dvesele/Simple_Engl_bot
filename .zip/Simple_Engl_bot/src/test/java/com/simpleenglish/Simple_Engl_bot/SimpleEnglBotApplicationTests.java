package com.simpleenglish.Simple_Engl_bot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleEnglBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
